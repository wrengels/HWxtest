
## ----setup, include=FALSE------------------------------------------------
library(knitr)
library(knitcitations)
opts_chunk$set(fig.width=8, fig.height=5)
set.seed(60823316) 


## ----refs, include=FALSE-------------------------------------------------
#bib <- read.bibtex('~/DropBox/HWxtest/bibHW.bib')
wd <- dirname(getwd())
wd <- paste(wd,"/inst/bibHW.bib",sep="")
bib <- read.bibtex("bibHW.bib")
me2009 <- ref("10.1534/genetics.109.108977")
levene1949 <- ref("10.1214/aoms/1177730093")
haldane1954 <- ref("10.1007/BF02985085")
louis1987 <- ref("10.2307/2531534")
guo1992 <- ref("10.2307/2532296")
ward2014 <- ref("10.1093/biostatistics/kxt028")
rousset1995 <- bib[["R1995"]]
robertson1984 <- bib[["robertson1984"]]
genepop007 <- bib[["genepop007"]]


## ----results="asis", echo=FALSE------------------------------------------
bibliography("html")


