
## ----setup, include=FALSE------------------------------------------------
library(knitr)
library(knitcitations)
library(HWxtest)
library(adegenet)
figw <- 8
figh <- 6
set.seed(60823316) 


## ----refs, include=FALSE-------------------------------------------------
#bib <- read.bibtex('~/DropBox/HWxtest/bibHW.txt')
wd <- dirname(getwd())
wd <- paste(wd,"/inst/bibHW.txt",sep="")
bib <- read.bibtex("bibHW.txt")
engels2009 <- ref("10.1534/genetics.109.108977")
levene1949 <- ref("10.1214/aoms/1177730093")
haldane1954 <- ref("10.1007/BF02985085")
louis1987 <- ref("10.2307/2531534")
guo1992 <- ref("10.2307/2532296")
ward2014 <- ref("10.1093/biostatistics/kxt028")
rousset1995 <- bib[["rousset1995"]]
robertson1984 <- bib[["robertson1984"]]
genepop007 <- bib[["genepop007"]]
adegenet <- ref("10.1093/bioinformatics/btn129")
pegas <- ref("10.1093/bioinformatics/btp696")
morin2012 <- bib[["morin2012"]]


## ----set-options, echo=FALSE, cache=FALSE--------------------------------
options(width = 120)


## ----include=FALSE-------------------------------------------------------
obs <- c(83, 49, 18, 74, 34, 21)


## ----entera--------------------------------------------------------------
obs <- c(83, 49, 18, 74, 34, 21)


## ----call1---------------------------------------------------------------
result <- hw.test(obs)
result


## ----plot1, fig.width=figw, fig.height=figh------------------------------
hw.test(obs, histobins=T)


## ----plot2, fig.width=figw, fig.height=figh------------------------------
hw.test(obs, histobins=T, detail=0, statName="U")


## ----testwhales----------------------------------------------------------
data(whales.genind)
wtest <- hw.test(whales.genind)


## ----dfwhales------------------------------------------------------------
dfwhales <- hwdf(wtest)
dfwhales[1:10,]


## ----getcounts-----------------------------------------------------------
counts1 <- wtest$P1$Bmys42aK46_R225_K232$genotypes
counts1


## ----biggerB-------------------------------------------------------------
hw.test(counts1, detail=1, B=1000000)


## ----bigger cutoff-------------------------------------------------------
counts2 <- wtest$P1$Bmys43Y237_Y377$genotypes
hw.test(counts2, detail=1, cutoff=2e8)


## ----Udataframe----------------------------------------------------------
hwdf(wtest, statName="U")[1:10,]


## ----results="asis", echo=FALSE------------------------------------------
bibliography("html")


