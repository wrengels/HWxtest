#' This is a data file with some HW examples

#' @name HWcases
#' @docType data
#' @references \href{http://dx.doi.org/10.2307/2532296}{Guo and Thompson, 1992}
#' @keywords data
NULL
